VCam Kimiki Windows Relay - SAFE
================================

Dung voi DEB safe:
- com.lumiere.vcamlumiere_2.2.031_kimiki_universal_safe.deb

Server:
- API: https://vc.kimiki.bond/vcam
- Tai khoan test ban dau: admin / 1234

Cach dung:
1. Giai nen folder nay tren Windows.
2. Chay relay.exe.
3. Dang nhap bang tai khoan tren server.
4. De cua so relay.exe mo trong luc stream.
5. OBS:
   - Server: rtmp://<IP-LAN-may-tinh>/live
   - Stream Key: de trong.
6. Tren iPhone, mo menu Vcam. Neu menu mo truoc relay, bam Hide roi mo lai de quet RTMP.
7. Bat LIVE tren iPhone.

Ghi chu:
- Khong copy relaykey.bin cu. File relaykey.bin se tu tao sau lan login dau tien.
- Neu port 1935 bi chiem, tat relay/MediaMTX/MonaServer cu roi mo relay.exe lai.
- Brand UI hien van giu @lumierephan theo yeu cau.