# Relay

High-performance relay runtime.

## Cấu trúc thư mục
```
Relay.exe                   # File thực thi chính
config.json             # Cấu hình ứng dụng
settings.ini            # Tùy chọn người dùng
vault.v2.enc.bin        # Vault dữ liệu (mã hóa AES-256)
manifest.json           # Manifest gói cài đặt
data/                   # Tài nguyên & dữ liệu
lib/                    # Thư viện runtime
logs/                   # Nhật ký hoạt động
```

## Yêu cầu hệ thống
- Windows 10/11 (x64)
- 4 GB RAM