VCam Kimiki Windows Relay - VcamPlus Contact
===========================================

Dung voi DEB:
- com.lumiere.vcamlumiere_2.2.031_kimiki_universal_safe_vcamplus_metadata.deb

Server:
- API: https://vc.kimiki.bond/vcam

Da doi trong goi nay:
- Relay console contact: Tele: @vcamplus
- DEB Sileo metadata: VcamPlus

Chua doi trong buoc nay:
- UI title trong menu van la tele: @lumierephan
- Watermark/chữ chạy quanh mép van giu nguyen
- Backend VCAM_CODE_MARKER van phai la: tele: @lumierephan

Cach dung:
1. Giai nen folder nay tren Windows.
2. Chay relay.exe.
3. Dang nhap bang tai khoan tren server.
4. OBS:
   - Server: rtmp://<IP-LAN-may-tinh>/live
   - Stream Key: de trong.
5. iPhone mo menu Vcam, bat LIVE.

Ghi chu:
- Khong copy relaykey.bin cu sang may khach.
- Neu port 1935 bi chiem, tat relay/MediaMTX/MonaServer cu roi mo relay.exe lai.